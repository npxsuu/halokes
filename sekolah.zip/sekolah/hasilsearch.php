<?php
echo '<table>';
$kata= $_POST['search'];
$sql_cari="SELECT * FROM berita WHERE UPPER(judul) LIKE '%$kata%' OR UPPER(isi_berita) LIKE '%$kata%'";
$qry_cari = mysqli_query($connect, $sql_cari) or die ("Gagal Query Cari");
$jumlah=mysqli_num_rows($qry_cari);
if ($jumlah > 0){
echo "<tr><td>
Ditemukan <b>$jumlah</b> berita dengan kata <b>$kata</b> : <ul>";
while($r=mysqli_fetch_array($qry_cari)){
echo "<li><a href='?p=beritatampil&id=$r[id_berita]'>$r[judul]</a></li>";
}
echo "</ul></td></tr>";
}
else{
echo "<tr><td>Tidak ditemukan berita dengan kata <b>$kata</b></td></tr>";
}
echo "<tr><td><br>
[ <a href=javascript:history.go(-1)>Kembali</a> ]</td></tr>";
echo '</table>';
?>