<ul id="hmenu" class="sf-menu sf-js-enabled sf-shadow">
                <li class="current" style="border:none"> 
                  <a class="toplvl sf-with-ul" href="./">Home</a></li>
              <li> 
                  <a href="?p=profil" class="toplvl">Profil</a>  
                  <ul>
                    <li> 
                      <a href="#">Sejarah</a></li>
                    <li class="current"> 
                      <a href="#">Visi & Misi</a>  
                      <ul>
                        <li class="current"><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                    <li> 
                      <a href="#">Struktur Organisasi</a>  
                      <ul>
                        <li><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                    <li> 
                      <a href="#">Pengajar & Staff</a>  
                      <ul>
                        <li><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                  </ul> 
              </li>
              <li> 
                  <a class="toplvl" href="#">Akademik</a>  
                  <ul>
                    <li> 
                      <a href="#">Prestasi</a>                    </li>
                    <li class="current"> 
                      <a href="#">Ekstrakurikuler</a>  
                      <ul>
                         <li class="current"><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                    <li> 
                      <a href="#">Info Beasiswa</a>  
                      <ul>
                        <li><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                    <li> 
                      <a href="#">Fasilitas</a>  
                      <ul>
                        <li><a href="#">menu item</a></li>
                        <li><a href="#">menu item</a></li>
                      </ul> 
                    </li>
                  </ul> 
              </li>
              <li> 
                  <a class="toplvl" href="#">Galeri Foto</a></li>
              <li> 
                  <a class="toplvl" href="#">Kontak Kami</a></li>    
              <li> 
                  <a class="toplvl" href="#">Buku Tamu</a></li>
          </ul>