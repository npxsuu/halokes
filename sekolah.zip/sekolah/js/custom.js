$(document).ready( function() { 
	$('ul.sf-menu').superfish();
	$('.sidebox2 h2').corner('5px');
	$('#wrapper .border-top').pngie();
	$('#container .ft').pngie();
	$('#container .hd').pngie();
	$('#container .bd').pngie();
	$('.sidebox1 h2').corner('5px');
	$('#wrapper .overlay').pngie();
});