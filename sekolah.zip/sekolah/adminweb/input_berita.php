<?php

$lokasi_file = $_FILES['fupload']['tmp_name'];
$nama_file   = $_FILES['fupload']['name'];

// Apabila ada gambar yang diupload
if (!empty($lokasi_file)){  
   move_uploaded_file($lokasi_file,"foto_berita/$nama_file");
   $masuk = mysqli_query($connect,"INSERT INTO berita(judul,
                                    id_kategori,
                                    isi_berita,
                                    jam,
                                    tanggal,
                                    hari,
                                    gambar) 
                           VALUES('$_POST[judul]',
                                  '$_POST[kategori]',
                                  '$_POST[isi_berita]',
                                  '$jam_sekarang',
                                  '$tgl_sekarang',
                                  '$hari_ini',
                                  '$nama_file')");
  }
  // Apabila tidak ada gambar yang di upload
  else{
  $masuk = mysqli_query($connect,"INSERT INTO berita(judul,
                                  id_kategori,
								  isi_berita,
                                  jam,
                                  tanggal,
								  hari) 
                          VALUES('$_POST[judul]',
                                 '$_POST[kategori]',
                                 '$_POST[isi_berita]',
                                 '$jam_sekarang',
                                 '$tgl_sekarang',
                                 '$hari_ini')");
  }

if($masuk){		
	echo "Data berhasil disimpan";	 
	echo "<meta http-equiv='refresh' content='0; url=?p=tampil_berita'>";
}
else{
	echo "Data gagal disimpan</br>";
	echo "Ada yang error : ".mysqli_error();
}
 
?>


