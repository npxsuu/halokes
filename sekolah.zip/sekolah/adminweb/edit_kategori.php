<?php
	$edit = mysqli_query($connect,"select * from kategori_berita where id_kategori = '$_GET[id]'");
	$r = mysqli_fetch_array($edit);
	echo "<h2>Isikan Kategori</h2>
	<form action=?p=update_kategori method=POST>
	<fieldset>
	<legend><b>Form Edit Kategori</b></legend>
	<table width=300>
	<input type=hidden name=id value='$r[id_kategori]'/>
	<tr>
	<td>Kategori </td>
	<td>: <input type=text name=kategori value='$r[nama_kategori]' /></td>
	</tr>
	<tr>
	<td>&nbsp;</td>
	<td><input type=submit name=submit value=Simpan /> <input type=button value=Batal onclick=self.history.back()></td></tr></td>
	</tr>
	</table>
	</fieldset>
	</form>";
?>