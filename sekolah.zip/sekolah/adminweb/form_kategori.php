<script language="javascript">
function validasi(form){
if (form.kategori.value == ""){
alert("Anda belum mengisikan Kategori");
form.kategori.focus();
return (false);
}
return (true);
}
</script>

<?php
	echo "<h2>Input Data Kategori</h2>
	<form action=?p=input_kategori method=POST onsubmit=\"return validasi(this)\">
	<fieldset>
	<legend><b>Form Kategori</b></legend>
	<table>
	<tr><td>Kategori </td>
	<td>: <input type=text name=kategori /></td>
	</tr>
	<tr><td>&nbsp;</td>
	<td><input type=submit name=submit value=Simpan /> <input type=button value=Batal onclick=self.history.back()></a> </td>
	</tr>
	</table>
	</fieldset>
	</form>";
?>