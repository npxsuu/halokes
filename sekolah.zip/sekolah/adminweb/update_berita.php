<?php

$lokasi_file = $_FILES['fupload']['tmp_name'];
$nama_file   = $_FILES['fupload']['name'];

// Apabila gambar tidak diganti
if (empty($lokasi_file)) {
   $ubah = mysqli_query($connect,"UPDATE berita SET judul   = '$_POST[judul]',
                               id_kategori = '$_POST[kategori]',
                               isi_berita  = '$_POST[isi_berita]'  
                           WHERE id_berita = '$_POST[id]'");
  }
  // Apabila gambar diganti
  else{
    move_uploaded_file($lokasi_file,"foto_berita/$nama_file");
   $ubah = mysqli_query($connect,"UPDATE berita SET judul   = '$_POST[judul]',
                               id_kategori = '$_POST[kategori]',
                               isi_berita  = '$_POST[isi_berita]',  
                               gambar      = '$nama_file'   
                           WHERE id_berita = '$_POST[id]'");
  }
 
  if($ubah){		
	echo "Data berhasil diubah";	 
	echo "<meta http-equiv='refresh' content='0; url=?p=tampil_berita'>";
}
else{
	echo "Data gagal diubah</br>";
	echo "Ada yang error : ".mysql_error();
}				
?>
