<?php
	echo "<h2>Kategori Berita</h2>
	<table id=tables width=250>
	<tr><th>No</th><th>Kategori</th><th>Aksi</th></tr>";
	$no = 1;
	$tampil = mysqli_query($connect,"select * from kategori_berita ORDER BY id_kategori DESC");
	while ($r=mysqli_fetch_array($tampil)){
	echo "<tr><td>$no</td>
	<td>$r[nama_kategori]</td>
	<td align=center>
	<a href=?p=edit_kategori&id=$r[id_kategori]>Edit</a> |
	<a href=?p=hapus_kategori&id=$r[id_kategori] onClick=\"return confirm('Anda yakin menghapus kategori berita $r[nama_kategori]?')\">Hapus</a></td>
	</tr>";
	$no++;
	}
	echo "<tr><td colspan=2>&nbsp;</td>
	<td align='center'><a href=?p=form_kategori>Tambah</a></td>
	</tr>";
	echo "</table>";
?>