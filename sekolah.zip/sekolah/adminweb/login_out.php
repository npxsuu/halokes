<?php
	session_start();
	// menghapus semua variabel session
	session_destroy();
	header('location:index.php');
?>