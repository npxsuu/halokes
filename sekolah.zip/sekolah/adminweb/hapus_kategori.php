<?php
	mysqli_query($connect,"DELETE FROM kategori_berita WHERE id_kategori='$_GET[id]'");
	echo "<meta http-equiv='refresh' content='0; url=?p=tampil_kategori'";
?>