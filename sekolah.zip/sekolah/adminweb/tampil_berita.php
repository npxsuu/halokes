<?php

echo "<h2>Berita</h2>
        <table id=tables width='100%'>
        <tr><th>No</th><th>Judul</th><th>Tgl. Posting</th><th>Aksi</th></th></tr>";
  $no = 1;
  $tampil=mysqli_query($connect,"SELECT * FROM berita ORDER BY id_berita DESC");	
  while ($r=mysqli_fetch_array($tampil)){
    $tgl_posting=tgl_indo($r['tanggal']);
    echo "<tr><td align='center'>$no</td>
          <td>$r[judul]</td>
          <td>$tgl_posting</td>
		      <td align='center'><a href=?p=edit_berita&id=$r[id_berita]>Edit</a> | 
		      <a href=?p=hapus_berita&id=$r[id_berita] onClick=\"return confirm('Anda yakin menghapus judul berita $r[judul]?')\">Hapus</a></td>
		    </tr>";
    $no++;
  }
    echo "<tr><td colspan=3>&nbsp;</td>
          <td align='center'><a href=?p=form_berita>Tambah</a></td>
		    </tr>";
  echo "</table>";
?>