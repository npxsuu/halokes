<?php
	$masuk = mysqli_query($connect,"insert into kategori_berita (nama_kategori)
		values ('$_POST[kategori]')");

	if($masuk){
		echo "Data berhasil disimpan";
	echo "<meta http-equiv='refresh' content='0; url=?p=tampil_kategori'";
	}
	else{
		echo "Data gagal disimpan</br>";
		echo "Ada yang error : ".mysql_error();
	}
?>