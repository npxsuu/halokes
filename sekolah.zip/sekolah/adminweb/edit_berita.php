<?php

  $edit = mysqli_query($connect,"SELECT * FROM berita WHERE id_berita='$_GET[id]'");
  $r    = mysqli_fetch_array($edit);

  echo "<h2>Edit Berita</h2>
        <form method=POST enctype='multipart/form-data' action=?p=update_berita>
		
        <table width=510>
		<input type=hidden name=id value=$r[id_berita]>
        <tr><td>Judul</td>     <td> : <input type=text name=judul size=40 value='$r[judul]'></td></tr>
        <tr><td>Kategori</td>  <td> : <select name=kategori>";
 
  $tampil=mysqli_query($connect,"SELECT * FROM kategori_berita ORDER BY nama_kategori");
  while($w=mysqli_fetch_array($tampil)){
    if ($r[id_kategori]==$w[id_kategori]){
      echo "<option value=$w[id_kategori] selected>$w[nama_kategori]</option>";
    }
    else{
      echo "<option value=$w[id_kategori]>$w[nama_kategori]</option>";
    }
  }
  echo "</select></td></tr>
        <tr><td>Isi Berita</td><td> &nbsp; <textarea name=isi_berita cols=45 rows=6>$r[isi_berita]</textarea></td></tr>
        <tr><td>Gambar</td><td> : <img src='foto_berita/$r[gambar]' width=150 height=100></td></tr>
        <tr><td>Ganti Gbr</td>    <td> : <input type=file name=fupload size=30> *)</td></tr>
        <tr><td colspan=2>*) Dikosongkan saja jika gambar tidak diubah, </td></tr>
        <tr><td colspan=2><input type=submit value=Update>
        <input type=button value=Batal onclick=self.history.back()></td></tr>
        </table>
        </form>";
?>
