<?php

mysqli_query($connect,"DELETE FROM berita WHERE id_berita='$_GET[id]'");

echo "<meta http-equiv='refresh' content='0; url=?p=tampil_berita'>";
?>

