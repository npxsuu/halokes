<h2>WELCOME TO CONTROL PANEL</h2>
<?php echo $_SESSION['username']; ?> bisa menggunakan menu disamping untuk mengakses fitur yang ada.

