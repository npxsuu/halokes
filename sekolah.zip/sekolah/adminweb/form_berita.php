<script language="javascript">
function validasi(form){
  if (form.judul.value == ""){
    alert("Anda belum mengisikan Judul");
    form.judul.focus();
    return (false);
  }
  return (true);
}
</script>

<?php

  echo "<h2>Tambah Berita</h2>
        <form method=POST action=?p=input_berita enctype='multipart/form-data' onsubmit=\"return validasi(this)\">
        <table width=\"100%\">
        <tr><td>Judul</td>     <td> : <input type=text name=judul size=60></td></tr>
        <tr><td>Kategori</td>  <td> : 
        <select name=kategori>
        <option value=0 selected>- Pilih Kategori -</option>";
 
  $tampil=mysqli_query($connect,"SELECT * FROM kategori_berita ORDER BY nama_kategori");
  while($r=mysqli_fetch_array($tampil)){
    echo "<option value=$r[id_kategori]>$r[nama_kategori]</option>";
  }
  echo "</select></td></tr>
        <tr><td>Isi Berita</td><td> &nbsp; <textarea name=isi_berita cols=45 rows=6></textarea></td></tr>
        <tr><td>Gambar</td>    <td> : <input type=file name=fupload size=40></td></tr>
        <tr><td colspan=2><input type=submit value=Simpan>
        <input type=button value=Batal onclick=self.history.back()></td></tr>
        </table>
        </form>";

?>
