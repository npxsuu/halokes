<?php
$ubah = mysqli_query($connect,"UPDATE kategori_berita SET nama_kategori = '$_POST[kategori]' where id_kategori = '$_POST[id]'");
if($ubah){
	echo "Data berhasil diubah";
	echo "<meta http-equiv='refresh' content='0; url=?p=tampil_kategori'";

}
else{
	echo "Data gagal diubah</br>";
	echo "Ada yg error hihi :".mysql_error();

}
?>