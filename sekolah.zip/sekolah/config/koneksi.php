<?php
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "sekolah_003";

	$connect = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname)
	or die("koneksi gagal");
?>