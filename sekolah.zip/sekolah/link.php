<table>
<tr>
	<td><a href="#"><img src="images/uli.gif"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/suyanto_consulting_150x45.gif"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/webometrics.jpg"></a></td>
</tr>
</table>