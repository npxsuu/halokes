<?php
$tampil=mysqli_query($connect,"SELECT * FROM berita b,kategori_berita k where k.id_kategori=b.id_kategori and id_berita=$_GET[id]");
while ($r=mysqli_fetch_array($tampil)){
$tgl_posting=tgl_indo($r['tanggal']);
mysqli_query($connect,"UPDATE berita SET counter=$r[counter]+1
WHERE id_berita='$_GET[id]'");
echo "
<div class=jud>$r[judul]</div><br>
<span class=tulis>Kategori: <b><u>$r[nama_kategori]</u></b><br>
<span class=hari>$r[hari], $tgl_posting - $r[jam] WIB</span><br><br>
<table align=center><tr><td><img src='adminweb/foto_berita/$r[gambar]' width=300 height=300/></td></tr></table>
<p>$r[isi_berita]</p>";
echo "<td align=center>
<a href=javascript:history.go(-1)> [ Kembali ]</a> </td><br><br>";
}
?>