<table>
<tr>
	<td><a href="#"><img src="images/new_Apicta_2.png"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/inaicta.png"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/tesca.png"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/indosat_wireless.png"></a></td>
</tr>
<tr>
	<td><a href="#"><img src="images/new_Adoc.png"></a></td>
</tr>
<tr>
	<td align="center"><a href="#"><img src="images/depdiknas.png"></a></td>
</tr>
</table>