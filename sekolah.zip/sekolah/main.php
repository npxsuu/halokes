<?php
$batas=5; //satu halaman menampilkan 5 baris berita
if(isset($_GET['halaman']))
{
$halaman=$_GET['halaman'];
$posisi=null;
}
if(empty($halaman)){
$posisi=0;
$halaman=1;
}else{
$posisi=($halaman-1)*$batas;
}
echo "<table width=\"100%\">";
$terkini= mysqli_query($connect,"SELECT * FROM berita ORDER BY id_berita DESC limit $posisi,$batas");
$no=$posisi+1;
while($t=mysqli_fetch_array($terkini)){
$tgl = tgl_indo($t['tanggal']);
echo "<tr><td>$t[hari], $tgl</td></tr>";
echo "<tr><td><a href=?p=beritatampil&id=$t[id_berita] class=judul>$t[judul]</a></td></tr>";
echo "<tr><td><p>";
if ($t['gambar']!=''){
echo "<img src='adminweb/foto_berita/$t[gambar]' width=120 height=100 hspace=10 border=0 align=left>";
}
echo substr($t['isi_berita'], 0, 400);
echo " ... <a href=?p=beritatampil&id=$t[id_berita]>Selengkapnya</a></p>
<hr color=#D8D8D8 size=2></td></tr>";
}
echo "</table>";
?>
<p><?php
$sql_paging = mysqli_query($connect,"select * from berita");
$jmldata = mysqli_num_rows($sql_paging);
$jumlah_halaman = ceil($jmldata / $batas);
echo "Halaman :";
for($i = 1; $i <= $jumlah_halaman; $i++)
if($i != $halaman) {
echo "<a href=?p=main&halaman=$i>$i</a>|";
} else {
echo "<b>$i</b>|";
}
?> </p>